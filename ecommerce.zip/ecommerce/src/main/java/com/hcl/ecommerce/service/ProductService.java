package com.hcl.ecommerce.service;

import java.util.List;

import com.hcl.ecommerce.dto.ProductResponseDto;

public interface ProductService {

List<ProductResponseDto> searchProduct(String searchItem);    	
    


}
