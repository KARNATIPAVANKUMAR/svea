package com.hcl.ecommerce.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.ecommerce.entity.Product;

@Repository
public interface ProductDao extends JpaRepository<Product,Integer> {
	List<Product> findByProductNameContains(String searchItem);
     Product findByProductId(int productId);
	Product findByProductNameAndDescriptionAndPrice(String productName, String description, double price);
    


}
