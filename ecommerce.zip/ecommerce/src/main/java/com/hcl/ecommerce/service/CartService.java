package com.hcl.ecommerce.service;

import java.util.List;

import com.hcl.ecommerce.dto.ProductResponseDto;

public interface CartService {
public String addToCart(int userId,int productId);
	
	public String deleteFromCart(int userId,int productId);
	
	public List<ProductResponseDto> displayCart(int userId);

}
