package com.hcl.ecommerce.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcl.ecommerce.dao.CartDao;
import com.hcl.ecommerce.dao.ProductDao;
import com.hcl.ecommerce.dao.UserDao;
import com.hcl.ecommerce.dto.ProductDto;
import com.hcl.ecommerce.dto.ProductResponseDto;
import com.hcl.ecommerce.entity.Cart;
import com.hcl.ecommerce.entity.Product;
import com.hcl.ecommerce.entity.User;
import com.hcl.ecommerce.exception.ProductNotExistException;
import com.hcl.ecommerce.exception.ValidationExceptionHandler;

public class CartServiceImpl implements CartService {
	@Autowired
	CartDao cartDao;
	@Autowired
	ProductDao productDao;
	@Autowired
	UserDao userDao;

	@Override
	public String addToCart(int userId, int productId) {
		if(!userDao.existsById(userId)) {
			throw new ValidationExceptionHandler("User Id does not exists");
		}
		if(!productDao.existsById(productId)) {
			throw new ValidationExceptionHandler("Product does not exists");
		}
		Cart cart = new Cart();
		Product products = new Product();
		User user = new User();
		ProductDto productDto = new ProductDto();
		products = productDao.getById(productId);
		user = userDao.getById(userId);
			BeanUtils.copyProperties(products, productDto);
			cart.setProductName(productDto.getProductName());
			cart.setDescription(productDto.getDescription());
			cart.setPrice(productDto.getPrice());
			cart.setUser(user);
			cartDao.save(cart);
			return "Product added to cart successfully";
	}

	@Override
	public String deleteFromCart(int userId, int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProductResponseDto> displayCart(int userId) {
		if(!userDao.existsById(userId)) {
			throw new ValidationExceptionHandler("User Id does not exists");
		}

		List<ProductResponseDto> list1 = new ArrayList<ProductResponseDto>();
		
		List<Cart> list = cartDao.displayCart(userId);
		System.out.println(list);
		if(!list.isEmpty()) {
		for (Cart cart : list) {
			ProductResponseDto productResponseDto = new ProductResponseDto();
			BeanUtils.copyProperties(cart, productResponseDto);
			list1.add(productResponseDto);
		}
		}
		else
			throw new ProductNotExistException("No items in the cart");
		return list1;
	}
	}


