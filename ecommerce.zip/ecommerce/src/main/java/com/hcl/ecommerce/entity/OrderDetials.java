package com.hcl.ecommerce.entity;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="orders")

public class OrderDetials {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int OrderId;
private Date createdDate;
	
	
	@ManyToOne(targetEntity=Product.class)
	@JoinColumn(name="productId")
	private Product product;
	@ManyToOne(targetEntity=User.class)
	@JoinColumn(name="customer_id",referencedColumnName="customerId")
    private User user;
	public int getOrderId() {
		return OrderId;
	}
	public void setOrderId(int orderId) {
		OrderId = orderId;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	

	

}
