package com.hcl.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.ecommerce.dto.OrderResponseDto;
import com.hcl.ecommerce.service.OrderService;

@RestController
public class OrderController {
	@Autowired
	OrderService orderService;

	@PostMapping("api/products")
	public ResponseEntity<String> orderItem( int userId){
		return new ResponseEntity<String>(orderService.orderItem(userId),HttpStatus.OK);
	}
	
	@GetMapping("/api/products")
	public ResponseEntity<List<OrderResponseDto>> displayOrders(int userId){
		return new ResponseEntity<List<OrderResponseDto>>(orderService.displayOrders(userId),HttpStatus.OK);
	}
	

}
