package com.hcl.ecommerce.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.ecommerce.dao.CartDao;
import com.hcl.ecommerce.dao.OrderDao;
import com.hcl.ecommerce.dao.ProductDao;
import com.hcl.ecommerce.dao.UserDao;
import com.hcl.ecommerce.dto.OrderResponseDto;
import com.hcl.ecommerce.entity.Cart;
import com.hcl.ecommerce.entity.OrderDetials;
import com.hcl.ecommerce.entity.Product;
import com.hcl.ecommerce.exception.ProductNotExistException;
import com.hcl.ecommerce.exception.ValidationExceptionHandler;
@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	CartDao cartDao;
	@Autowired
	OrderDao orderDao;
	@Autowired
	UserDao userDao;
	@Autowired
	ProductDao productDao;
	
	@Override
	public String orderItem(int userId) {
		
		//List<OrderDetails> orderList = new ArrayList<OrderDetails>();
		if(!userDao.existsById(userId)) {
			throw new ValidationExceptionHandler("User Id does not exists");
		}
		List<Cart> cart = cartDao.displayCart(userId);
		List<Product> productList=new ArrayList<Product>();
		if(!cart.isEmpty()) {
		for(Cart itemList:cart) {
			Product product = new Product();
			product=productDao.findByProductNameAndDescriptionAndPrice(itemList.getProductName(), itemList.getDescription(), itemList.getPrice());
			productList.add(product);
		}
		for(Cart itemList1:cart) {
			OrderDetials orderDetails = new OrderDetials();
			
			orderDetails.setCreatedDate(new Date());
//			orderDetails.setProducts(productList);
//			System.out.println(orderDetails.getProducts());
			Product product = new Product();
			product=productDao.findByProductNameAndDescriptionAndPrice(itemList1.getProductName(), itemList1.getDescription(), itemList1.getPrice());
			BeanUtils.copyProperties(itemList1,orderDetails);
			orderDetails.setProduct(product);
			orderDao.saveAndFlush(orderDetails);
			
		}
		cartDao.deleteAll();
		}else 
			throw new ProductNotExistException("Empty cart.. continue shopping");
		return "Your order placed successfully";
	}

	@Override
	public List<OrderResponseDto> displayOrders(int userId) {
		
		if(!userDao.existsById(userId)) {
			throw new ValidationExceptionHandler("User Id does not exists");
		}
		List<OrderResponseDto> list = new ArrayList<OrderResponseDto>();
		List<Product> productList = new ArrayList<Product>();
		List<OrderDetials> orderList = orderDao.displayOrders(userId);
		if(!orderList.isEmpty()) {
		for(OrderDetials order:orderList) {
			OrderResponseDto orderResponseDto = new OrderResponseDto();
			Product product = new Product();
			product=productDao.findByProductId(order.getProduct().getProductId());
			//productList.add(products);
			BeanUtils.copyProperties(order, orderResponseDto);
			BeanUtils.copyProperties(product, orderResponseDto);
			list.add(orderResponseDto);
		}
		}else
			throw new ProductNotExistException("You haven`t ordered anything yet.. Place your first order");
		return list;
	}

}
