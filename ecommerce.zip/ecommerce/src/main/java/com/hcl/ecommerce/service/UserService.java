package com.hcl.ecommerce.service;

public interface UserService {
	public String UserLogin(String userName,String password);

}
