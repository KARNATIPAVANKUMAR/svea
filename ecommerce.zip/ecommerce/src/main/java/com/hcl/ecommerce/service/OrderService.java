package com.hcl.ecommerce.service;

import java.util.List;

import com.hcl.ecommerce.dto.OrderResponseDto;

public interface OrderService  {
	
	public List<OrderResponseDto> displayOrders(int userId);

	public String orderItem(int userId);  

}
