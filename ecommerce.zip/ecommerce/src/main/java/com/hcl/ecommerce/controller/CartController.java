package com.hcl.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.ecommerce.dto.ProductResponseDto;
import com.hcl.ecommerce.service.CartServiceImpl;

@RestController
public class CartController {
	
	@Autowired
	CartServiceImpl cartServiceImpl;
	
	@PostMapping("cart/{customerId}/{productId}")
	public ResponseEntity<String> addToCart(@PathVariable int userId,@PathVariable int productId){
		return new ResponseEntity<String>(cartServiceImpl.addToCart(userId, productId),HttpStatus.OK);
	}
	
	
	@GetMapping("cart/{userId}")
	public ResponseEntity<List<ProductResponseDto>> displayCart(@PathVariable int userId){
		return new ResponseEntity<List<ProductResponseDto>>(cartServiceImpl.displayCart(userId),HttpStatus.OK);
	}

}

