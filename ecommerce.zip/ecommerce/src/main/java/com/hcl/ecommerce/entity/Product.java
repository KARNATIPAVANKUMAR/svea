package com.hcl.ecommerce.entity;
import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.persistence.CascadeType;
import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import java.util.List;




@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private int productId;
	@NotNull
	@Column(name="product_name")
	private String productName;
	@NotNull
	@Column(name="description")
	private String description;
	@NotNull
	@Column(name="price")
	private double price;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="product")
	private List<OrderDetials> orders;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public List<OrderDetials> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderDetials> orders) {
		this.orders = orders;
	}
	
	
	

}
