package com.hcl.ecommerce;

public class ApiStatusCode {
	public static final int INVALID_DATA=401;
	public static final int VALIDATION_FAILED=205;
	public static final int PRODUCT_NOT_FOUND=504;

	

}
