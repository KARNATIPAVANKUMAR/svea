package com.hcl.ecommerce.service;

import javax.validation.ValidationException;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.hcl.ecommerce.dao.UserDao;
import com.hcl.ecommerce.dto.UserRequestDto;
import com.hcl.ecommerce.entity.User;
import com.hcl.ecommerce.exception.ValidationExceptionHandler;
@Service
public class UserServiceImpl implements UserService  {
	@Autowired
	UserDao userDao;

	@Override
	public String UserLogin(String userName, String password) {
		User user=new User();
		user=userDao.findByUserNameAndPassword(userName, password);
		if(user!=null) {
			return "LoginSuccess";
		}
		throw new ValidationExceptionHandler("Please Check Credentials");
	}

	
	

}
