package com.hcl.ecommerce.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.ecommerce.dao.ProductDao;
import com.hcl.ecommerce.dto.ProductDto;
import com.hcl.ecommerce.dto.ProductResponseDto;
import com.hcl.ecommerce.entity.Product;
import com.hcl.ecommerce.exception.ProductNotExistException;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao productDao;

	@Override
	public List<ProductResponseDto> searchProduct(String searchItem) {
		Product product=new Product();
		List<Product> productList=new ArrayList<Product>();
		List<ProductResponseDto> responseList=new ArrayList<ProductResponseDto>();
		System.out.println(productList);
		if(productList.size()!=0)
		{
			for(Product products:productList) {
				ProductResponseDto productResponse=new ProductResponseDto();
				product.setProductName(product.getProductName());
				product.setDescription(product.getDescription());
				product.setPrice(product.getPrice());
				BeanUtils.copyProperties(product, productResponse);
				System.out.println(product);
				System.out.println(productResponse);
				responseList.add(productResponse);
				System.out.println(responseList);
			}
			return responseList;
		}
		 throw new ProductNotExistException("ProductNot Found");
	}
	
		 public Product getProductById(int productId) {
			return productDao.findByProductId(productId);
		}
		
	

}
