package com.hcl.ecommerce.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hcl.ecommerce.entity.OrderDetials;
public interface OrderDao extends JpaRepository<OrderDetials, Integer> {
	@Query(value ="select * from orders c where c.userId=:userId",nativeQuery=true)
	   List<OrderDetials> displayOrders(@Param("userId") int userId);
	

}
